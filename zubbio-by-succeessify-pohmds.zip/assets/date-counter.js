  var settime = "{{ tag_time }}";
    (function (){
     if(settime.length  > 0 ){
        var countDownDate = new Date(settime).getTime();
                 
        var x = setInterval(function() { 
          // Get todays date and time
          var now = new Date().getTime(); 
          // Find the distance between now an the count down date
          var distance = countDownDate - now; 
          // Time calculations for days, hours, minutes and seconds
          var days = Math.floor(distance / (1000 * 60 * 60 * 24));
          if(days < 10 )
          {
            var days = '0' + days;
          }else{
            days = days;
          }
          var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          if(hours  < 10 )
          {
            var hours = '0' + hours;
          }else{
            hours = hours;
          }
          var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
          if(minutes  < 10 )
          {
            var minutes = '0' + minutes;
          }else{
            minutes = minutes;
          }
          var seconds = Math.floor((distance % (1000 * 60)) / 1000); 
          document.querySelector('.js-days').innerText = days;
          document.querySelector('.js-hours').innerText = hours;
          document.querySelector('.js-minutes').innerText = minutes;
          document.querySelector('.js-seconds').innerText = seconds;
          if (distance < 0) {
            clearInterval(x);
            document.getElementById("js_set_time").innerHTML = "Out of date";
          }
        }, 1000);
      }
    })();